import { Injectable } from '@angular/core';
import { proyecto } from '../clases/proyecto.model';

@Injectable({
  providedIn: 'root'
})
export class ProyectoServicioService {

  public proyecto: proyecto;
  public arrayProyectos: proyecto[] = []

  constructor(){
    this.proyecto = new proyecto()
  }

  crearProyecto(p:proyecto){
    this.proyecto = p
    this.arrayProyectos.push(p)
  }

  obtenerProyecto(): proyecto{
    return this.proyecto
  }

  obtenerArrayProyecto(): proyecto[]{
    return this.arrayProyectos;
  }

}
